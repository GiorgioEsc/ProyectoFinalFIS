/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package facturacion;

/**
 *
 * @author ANDRES
 */
public class Facturacion {

    /**
     * @param args the command line arguments
     */
   
    public static void main(String[] args) {
       new Interfaz_principal().setVisible(true);
    }

   
}
